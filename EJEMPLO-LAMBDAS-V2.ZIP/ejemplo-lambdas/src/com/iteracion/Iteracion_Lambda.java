package com.iteracion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Iteracion_Lambda {

	private static Map<String, Integer> mapa;

	public static void main(String[] args) {
		Iteracion_Lambda objeto = new Iteracion_Lambda();
//		objeto.Iteracion_Mapa();
		objeto.Iteracion_Lista();
	}

	public void Iteracion_Mapa() {
		// CREAMOS DATOS PARA SU USO
		mapa = new HashMap<>();
		mapa.put("A", 10);
		mapa.put("B", 20);
		mapa.put("C", 30);
		mapa.put("D", 40);
		mapa.put("E", 50);
		mapa.put("F", 60);
		// RECORRER/ITERAR EL MAPA POR CODIGO
		System.out.println("iteracion no funcional");
		for (Map.Entry<String, Integer> entry : mapa.entrySet()) {
			System.out.println("Clave : " + entry.getKey() + " Valor : " + entry.getValue());
		}
		// RECORRER/ITERAR EL MAPA MEDIANTE UNA EXPRESION LAMBDA
		System.out.println("iteracion funcional");
		mapa.forEach((clave, valor) -> System.out.println("Clave : " + clave + " Valor : " + valor));
		// ITERACION DEL MAPA DE FORMA FUNCIONAL REALIZANDO UNA OPERACION COMPLEJA
		mapa.forEach((clave, valor) -> {
			System.out.println("Clave : " + clave + " Valor : " + valor);
			if ("E".equals(clave)) {
				System.out.println("Hola E");
			}
		});
	}

	public void Iteracion_Lista() {
		// CREACION DE LA LISTA A USAR
		List<String> items = new ArrayList<>();
		items.add("A");
		items.add("B");
		items.add("C");
		items.add("D");
		items.add("E");
		// ITERACION POR CODIGO
		System.out.println("iteracion no funcional");
		for (String item : items) {
			System.out.println("Texto elemento: "+item);
		}
		// ITERACION FUNCIONAL
		System.out.println("iteracion funcional");
		items.forEach(item -> System.out.println("Texto elemento: "+item));
		// ITERACION DEL MAPA DE FORMA FUNCIONAL REALIZANDO UNA OPERACION COMPLEJA
		System.out.println("iteracion funcional con operacion compleja");
		items.forEach(item -> {
			if ("C".equals(item)) {
				System.out.println("Texto elemento: "+item);
			}
		});
		// REFERENCIA A METODO
		System.out.println("iteracion con referencia a metodo");
		items.forEach(System.out::println);
	}

}
