package com.ordenacion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Ordenacion_SinLambda implements Comparator<Developer> {

	public static void main(String[] args) {
		Ordenacion_SinLambda objeto = new Ordenacion_SinLambda();
		// OBTENEMOS DATOS PARA SU ORDENACION
		List<Developer> listDevs = getDevelopers();
		System.out.println("ANTES DE ORDENAR");
		for (Developer developer : listDevs) {
			System.out.println(developer);
		}
		// ORDENACION POR EDAD
		Collections.sort(listDevs, objeto);
		System.out.println("DESPUES DE ORDENAR");
		for (Developer developer : listDevs) {
			System.out.println(developer);
		}
	}

	private static List<Developer> getDevelopers() {
		// CREAMOS LA COLECCION
		List<Developer> result = new ArrayList<Developer>();
		// CARGAMOS DATOS
		result.add(new Developer("mkyong", new BigDecimal("70000"), 33));
		result.add(new Developer("alvin", new BigDecimal("80000"), 20));
		result.add(new Developer("jason", new BigDecimal("100000"), 10));
		result.add(new Developer("iris", new BigDecimal("170000"), 55));
		// RETORNAMOS LA LISTA
		return result;
	}

	@Override
	public int compare(Developer developer1, Developer developer2) {
		// ORDENACION POR EDAD EN ASCENDENTE
		return developer1.getEdad() - developer2.getEdad();
	}
}
