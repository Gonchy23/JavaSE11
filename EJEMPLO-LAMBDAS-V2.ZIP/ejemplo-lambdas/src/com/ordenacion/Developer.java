package com.ordenacion;

import java.math.BigDecimal;

public class Developer {

	private String nombre;
	private Integer edad;
	private BigDecimal sueldo;

	public Developer(String nombre, BigDecimal sueldo, Integer edad) {
		this.nombre = nombre;
		this.edad = edad;
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Developer [nombre=" + nombre + ", edad=" + edad + ", sueldo=" + sueldo + "]";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getEdad() {
		return edad;
	}

	public void setEdad(Integer edad) {
		this.edad = edad;
	}

	public BigDecimal getSueldo() {
		return sueldo;
	}

	public void setSueldo(BigDecimal sueldo) {
		this.sueldo = sueldo;
	}

}
