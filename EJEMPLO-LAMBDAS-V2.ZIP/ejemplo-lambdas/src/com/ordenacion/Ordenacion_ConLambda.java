package com.ordenacion;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Ordenacion_ConLambda {

	public static void main(String[] args) {
		// OBTENEMOS DATOS PARA SU ORDENACION
		List<Developer> listDevs = getDevelopers();
		System.out.println("ANTES DE ORDENAR");
		for (Developer developer : listDevs) {
			System.out.println(developer);
		}
		System.out.println("DESPUES DE ORDENAR");
		// ORDENACION POR EDAD EN ASCENDENTE DEFINIDO POR UNA LAMBDA
		listDevs.sort((Developer developer1, Developer developer2) -> developer1.getEdad() - developer2.getEdad());
		// MOSTRAR EL CONTENIDO DE LA LISTA
		listDevs.forEach((developer) -> System.out.println(developer));
		// ORDENACION POR SALARIO CREANDO UN OBJETO COMPARATOR
		Comparator<Developer> salaryComparator = (developer1, developer2) -> developer1.getSueldo()
				.compareTo(developer2.getSueldo());
		listDevs.sort(salaryComparator);
		// MOSTRAR EL CONTENIDO DE LA LISTA
		System.out.println("ordenado por sueldo");
		listDevs.forEach((developer) -> System.out.println(developer));
		// ORDENACION POR SALARIO CREANDO UN OBJETO COMPARATOR ORDENANDO EN REVERSE
		Comparator<Developer> salaryComparator2 = (developer1, developer2) -> developer1.getSueldo()
				.compareTo(developer2.getSueldo());
		listDevs.sort(salaryComparator.reversed());
		// MOSTRAR EL CONTENIDO DE LA LISTA
		System.out.println("ordenado en sentido inverso por sueldo");
		listDevs.forEach((developer) -> System.out.println(developer));
	}

	private static List<Developer> getDevelopers() {
		// CREAMOS LA COLECCION
		List<Developer> result = new ArrayList<Developer>();
		// CARGAMOS DATOS
		result.add(new Developer("mkyong", new BigDecimal("70000"), 33));
		result.add(new Developer("alvin", new BigDecimal("80000"), 20));
		result.add(new Developer("jason", new BigDecimal("100000"), 10));
		result.add(new Developer("iris", new BigDecimal("170000"), 55));
		// RETORNAMOS LA LISTA
		return result;
	}

}