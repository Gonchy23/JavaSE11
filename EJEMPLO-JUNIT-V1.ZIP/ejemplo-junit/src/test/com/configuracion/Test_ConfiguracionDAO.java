package test.com.configuracion;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.configuracion.Configuracion_DAO;

public class Test_ConfiguracionDAO {
	// OBJETO A COMPROBAR
	private Configuracion_DAO confi_dao;
	private static int numero = 0;
	
	@BeforeClass
	public static void inicio_Prueba() {
		System.out.println("INICIAMOS LA PRUEBA ***********");
	}
	@AfterClass
	public static void fin_Prueba() {
		System.out.println("FINAL DE LA PRUEBA ***********");
	}
	
	@Before
	public void creacion_objeto() {
		// CREACION DEL OBJETO A TESTEAR
		confi_dao = new Configuracion_DAO();
		// DATOS DE LA PRUEBA
		confi_dao.setRuta_properties("/test/recursos/prueba_configuracion.properties");
		numero++;
		System.out.println("Numero de ejecuciones .. "+numero);
	}
	@ After
	public void metodo_Final() {
		System.out.println("Final de prueba ..... ");
	}

	@Test
	public void testConfiguracion_DAO() {
		System.out.println("LLAMADA AL METODO CONFIGURACION DAO");
		fail("Not yet implemented");
	}

	@Test
	public void testConfiguracion_DAOString() {
		System.out.println("LLAMADA AL METODO CONFIGURACION DAO CON PARAMETRO");
		fail("Not yet implemented");
	}

	@Test
	public void testCargar_Configuracion() {
		System.out.println("LLAMADA AL METODO CARGAR CONFIGURACION");
		fail("Not yet implemented");
	}

	@Test
	public void testModificar_Configuracion() {
		System.out.println("LLAMADA AL METODO MODIFICAR CONFIGURACION");
		fail("Not yet implemented");
	}

	@Test
	public void testEstablecer_OpcionesDefecto() {
		System.out.println("LLAMADA AL METODO ESTABLECER OPCIONES DEFECTO");
		fail("Not yet implemented");
	}

}
