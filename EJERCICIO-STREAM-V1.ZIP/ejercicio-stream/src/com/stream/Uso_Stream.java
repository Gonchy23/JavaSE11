package com.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Uso_Stream {

	public List<String> ordenar_PorEstacion(String rutanombre_fichero){
		List<String> lista_ordenada = null;
		try (Stream<String> flujo_lectura = Files.lines(Paths.get(rutanombre_fichero))) {
			lista_ordenada = flujo_lectura
									.sorted( (String linea1,String linea2) -> {
										String estacion1 = linea1.split(";")[9];
										String estacion2 = linea2.split(";")[9];
										return estacion1.compareTo(estacion2);
									})
									.collect(Collectors.toList());
		} catch (IOException e) {
			System.out.println("ERROR AL LEER EL FICHERO");
			e.printStackTrace();
		}
		
		
		return lista_ordenada;
	}
}
