package com.stream;

import java.util.List;

public class Inicio {

	public static void main(String[] args) {
		Uso_Stream objeto = new Uso_Stream();
		List<String> lista_mediciones = objeto.ordenar_PorEstacion("c:/rutaprueba/CYL 1997-2018.csv");
		System.out.println("");
	}

}
