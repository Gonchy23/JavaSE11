package com.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Ejemplos_Stream {
	/**
	 * Ordenar las mediciones del fichero por provincias.
	 * 
	 * @param rutanombre_fichero
	 * @return
	 */
	public List<String> ordenar_PorProvincias(String rutanombre_fichero) {
		List<String> lista_ordena = null;
		// CREACION DEL FLUJO DE LECTURA DEL FICHERO (OBJETO STREAM)
		try (Stream<String> flujo_lectura = Files.lines(Paths.get(rutanombre_fichero))) {
			lista_ordena = flujo_lectura.
								sorted((linea1, linea2) -> {// ORDENACION DE LA INFORMACION POR PROVINCIA
									String provincia1 = linea1.split(";")[8];
									String provincia2 = linea2.split(";")[8];
									return provincia1.compareTo(provincia2);
								})
								.collect(Collectors.toList());// OBTENCION DEL RESULTADO
		} catch (IOException e) {
			System.out.println("ERROR EN EL ACCESO AL FICHERO");
			e.printStackTrace();
		}
		// SE DEVUELVE LA LISTA DE MEDICIONES ORDENADA POR PROVINCIAS
		return lista_ordena;
	}
	/**
	 * Proceso de ordenacion del fichero de las mediciones por provincia y estacion de medicion de la provincia
	 * @param rutanombre_fichero
	 * @return
	 */
	public List<String> ordenar_PorProvinciaEstacion(String rutanombre_fichero) {
		List<String> lista_ordenada = null;
		// CREACION DEL FLUJO DE LECTURA DEL FICHERO (OBJETO STREAM)
		try (Stream<String> flujo_lectura = Files.lines(Paths.get(rutanombre_fichero))) {
			lista_ordenada = flujo_lectura
									.sorted((linea1, linea2) ->{
										String cadenas1[]= linea1.split(";");
										String provincia_estacion1 = cadenas1[8]+cadenas1[9];
										String cadenas2[]= linea2.split(";");
										String provincia_estacion2 = cadenas2[8]+cadenas2[9];
										return provincia_estacion1.compareTo(provincia_estacion2);
									})// ORDENACION DE LAS MEDICIONES POR PROVINCIA MAS ESTACION
									.collect(Collectors.toList());
		} catch (IOException e) {
			System.out.println("ERROR EN EL ACCESO AL FICHERO");
			e.printStackTrace();
		}
		// SE DEVUELVE LA LISTA DE MEDICIONES ORDENADA POR PROVINCIA Y ESTACION
		return lista_ordenada;
	}
	/**
	 * Proceso de filtrado de las mediaciones contenidas en el fichero.
	 * @param rutanombre_fichero Dondes esta y como se llama el fichero a tratar
	 * @param nombre_provincia Provincia de la cual queremos las mediciones
	 * @return
	 */
	public List<String> filtrar_PorProvincia(String rutanombre_fichero,String nombre_provincia){
		List<String> lista_filtrada = null;
		// CREACION DEL FLUJO DE LECTURA DEL FICHERO (OBJETO STREAM)
		try (Stream<String> flujo_lectura = Files.lines(Paths.get(rutanombre_fichero))) {
			lista_filtrada = flujo_lectura
								.filter(linea -> linea.contains(nombre_provincia))  // FILTRAMOS POR NOMBRE DE PROVINCIA
								.filter(linea -> !linea.split(";")[1].isEmpty()) // FILTRAMOS PON EL CONTENIDO DE LA COLUMNA DE CO
								.sorted((linea1,linea2)-> linea1.split(";")[9].compareToIgnoreCase(linea2.split(";")[9]))//ORDENAMOS POR ESTACION DE MUESTREO
								.collect(Collectors.toList()); // OBTENCION DEL RESULTADO DEL PROCESO
		} catch (IOException e) {
			System.out.println("ERROR EN EL ACCESO AL FICHERO");
			e.printStackTrace();
		}
		// SE DEVUELVE LA LISTA DE MEDICIONES
		return lista_filtrada;
	}
}
