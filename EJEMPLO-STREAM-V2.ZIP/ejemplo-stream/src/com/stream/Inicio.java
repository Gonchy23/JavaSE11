package com.stream;

import java.util.List;

public class Inicio {

	public static void main(String[] args) {
		Ejemplos_Stream objeto = new Ejemplos_Stream();
//		List<String> lista_ordenada = objeto.ordenar_PorProvincias("c:/rutaprueba/CYL 1997-2018.csv");
//		List<String> lista_ordenada2 = objeto.ordenar_PorProvinciaEstacion("c:/rutaprueba/CYL 1997-2018.csv");
		List<String> lista_ordenada3 = objeto.filtrar_PorProvincia("c:/rutaprueba/CYL 1997-2018.csv", "Soria");
		System.out.println("");
	}

}
