package com.funcional;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.function.Predicate;

public class Inicio {

	public static void main(String[] args) {
		// CREAMOS OBJETOS DE LA CLASE PERSONA
		Persona p1 = new Persona("pepe", 20);
		Persona p2 = new Persona("juan", 12);
		Persona p3 = new Persona("angela", 30);
		Persona p4 = new Persona("gema", 40);
		Persona p5 = new Persona("david", 15);
		// LISTA PARA CONTENER LOS OBJETOS DE LA CLASE PERSONA
		List<Persona> lista = new ArrayList<>();
		// CARGAMOS LA COLECCION CON LOS OBJETOS
		lista.add(p1);
		lista.add(p2);
		lista.add(p3);
		lista.add(p4);
		lista.add(p5);
		Inicio objeto = new Inicio();
		objeto.calcular_Media(lista);
		objeto.calcular_MediaFuncional(lista);
	}

	public void calcular_MediaFuncional(List<Persona> lista) {
		// HALLAR LA MEDIA DE EDAD DE LAS PERSONAS
		// DE FORMA FUNCIONAL
		OptionalDouble resultado = lista.stream()
				.filter(persona -> persona.getEdad() >= 18)
				.mapToInt(persona -> persona.getEdad())
				.average();
		// MOSTRAMOS EL RESULTADO
		if (resultado.isPresent()) {
			System.out.println("LA EDAD MEDIA ES (funcional) .. " + resultado.getAsDouble());
		}else {
			System.out.println("NO HAY DATOS PARA PODER OBTENER LA MEDIA");
		}
	}

	public void calcular_Media(List<Persona> lista) {
		// HALLAR LA MEDIA DE EDAD DE LAS PERSONAS
		int totalEdad = 0;
		int totalPersonas = 0;
		// CALCULO DE LA MEDIA DE LA EDAD DE LAS PERSONAS
		for (Persona p : lista) {
			if (p.getEdad() >= 18) {
				totalEdad += p.getEdad();
				totalPersonas++;
			}
		}
		// MOSTRAMOS EL RESULTADO
		System.out.println("LA EDAD MEDIA ES (no funcional) .. " + totalEdad / totalPersonas);
	}

}
