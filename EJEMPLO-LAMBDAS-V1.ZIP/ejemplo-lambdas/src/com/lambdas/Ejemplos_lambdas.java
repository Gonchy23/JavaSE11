package com.lambdas;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Ejemplos_lambdas {

	private static Consumer<Integer> c;
	private static BiConsumer<String, String> b;
	private static Predicate<String> p;

	public static void main(String[] args) {
		Ejemplos_lambdas objeto = new Ejemplos_lambdas();
		objeto.definicion_Consumer();
		objeto.operacion_Consumer(255, c);
		objeto.operacion_BiConsumer("Soy la operacion ", "biconsumer, Adios", b);

		// CREAMOS DATOS PARA UTILIZAR LAMBDAS
		List<String> languages = Arrays.asList("Java", "Scala", "C++", "Haskell", "Lisp");
		// DIFERENTES IMPLEMENTACIONES DEL METODO TEST DE LA INTERFACE FUNCIONAL
		System.out.println("LENGUAJES QUE COMIENCEN POR J :");
		filtro_coleccion(languages, str -> ((String) str).startsWith("J"));
		System.out.println("LENGUAJES QUE TERMINEN POR LA LETRA a ");
		filtro_coleccion(languages, (str) -> str.endsWith("a"));
		System.out.println("MOSTRAR TODOS LOS LENGUAJES :");
		filtro_coleccion(languages, (str) -> true);
		System.out.println("NO MUESTRA NADA AL NO PROCESARSE LOS ELEMENTOS : ");
		filtro_coleccion(languages, (str) -> false);
		System.out.println("MOSTRAR LOS LENGUAJES QUE TENGAN MAS DE 4 CARACTERES:");
		filtro_coleccion(languages, (str) -> ((String) str).length() > 4);
	}

	/**
	 * Metodo que tiene como parametro un objeto de tipo Predicate. La condicion
	 * sera implementada por la lambda que usemos al llamar al metodo.
	 * 
	 * @param nombres   Coleccion a usar.
	 * @param condicion Condicion a aplicara cada elemento de la coleccion.
	 */
	public static void filtro_coleccion(List<String> nombres, Predicate<String> condicion) {
		for (String nombre : nombres) {
			if (condicion.test(nombre)) {
				System.out.println(nombre + " ");
			}
		}
	}

	/**
	 * Ejemplos de definicion de lambdas que son recogidas en objetos para su
	 * posterior uso. Ventaja reusabilidad y no tener que repetir la definicion de
	 * la expresion.
	 */
	public void definicion_Consumer() {
		c = (Integer numero) -> {
			int y = 5;
			numero = numero * 2;
			numero = numero + y;
			System.out.println(numero);
		};// lambda que define la operacion del consumer
		b = (String x, String y) -> System.out.println(x + " : " + y); // lambda que define la operacion del biconsumer
		p = (String s) -> s == null;
	}

	/**
	 * Metodo para usar la operacion definida por la interface Consumer.
	 * 
	 * @param numero    Valor numerico a usar en la operacion
	 * @param operacion Implementacion de la interface Consumer
	 */
	public void operacion_Consumer(Integer numero, Consumer<Integer> operacion) {
		operacion.accept(numero);
	}

	/**
	 * Metodo para usar la operacion definida por la interface BiConsumer
	 * 
	 * @param x         Primer cadena de texto a usar en la operacion
	 * @param y         Segunda cadena de texto a usar en al operacion
	 * @param operacion Implementacion de la interface BiConsumer
	 */
	public void operacion_BiConsumer(String x, String y, BiConsumer<String, String> operacion) {
		operacion.accept(x, y);
	}
}
