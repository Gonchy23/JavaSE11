package com.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Uso_Stream {
	// CONJUNTO DE CONSTANTES DE CLASE PARA DEFINIR LA COLUMNA A TRATAR
	private static final int CO = 1;
	private static final int NO = 2;
	private static final int NO2 = 3;
	private static final int O3 = 4;
	private static final int PM1O = 5;
	private static final int PM25= 6;
	private static final int SO2 = 7;

	public List<String> ordenar_PorEstacion(String rutanombre_fichero){
		List<String> lista_ordenada = null;
		try (Stream<String> flujo_lectura = Files.lines(Paths.get(rutanombre_fichero))) {
			lista_ordenada = flujo_lectura
									.sorted( (String linea1,String linea2) -> {
										String estacion1 = linea1.split(";")[9];
										String estacion2 = linea2.split(";")[9];
										return estacion1.compareTo(estacion2);
									})
									.collect(Collectors.toList());
		} catch (IOException e) {
			System.out.println("ERROR AL LEER EL FICHERO");
			e.printStackTrace();
		}
		return lista_ordenada;
	}
	/**
	 * Proceso de calcular el numero de las mediciones de cualquier provincia y por cualquier tipo tipo de contaminante.
	 * @param rutanombre_fichero Ruta y nombre del fichero con los datos.
	 * @param provincia Nombre de la provincia a tratar.
	 * @param medicion Posicion de la columna a tratar
	 * @return Numero de mediciones realizadas
	 */
	public Long calcular_NumeroMediciones(String rutanombre_fichero,String provincia,int medicion) {
		long numero_mediciones = 0;
		try (Stream<String> flujo_lectura = Files.lines(Paths.get(rutanombre_fichero))) {
			numero_mediciones = flujo_lectura
											.filter(linea -> linea.contains(provincia))  // FILTRAMOS POR NOMBRE DE PROVINCIA
											.filter(linea -> !linea.split(";")[medicion].isEmpty())// FILTRAMOS PON EL CONTENIDO DE LA COLUMNA
											.count(); // OBTENEMOS EL NUMERO DE MEDICIONES (NUMERO DE ELEMENTOS DEL STREAM)
		} catch (IOException e) {
			System.out.println("ERROR AL LEER EL FICHERO");
			e.printStackTrace();
		}
		// RETORNAMOS EL VALOR BUSCADO
		return numero_mediciones;
	}
}
