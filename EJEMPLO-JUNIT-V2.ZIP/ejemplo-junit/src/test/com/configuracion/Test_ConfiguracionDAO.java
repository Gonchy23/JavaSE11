package test.com.configuracion;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.configuracion.Configuracion_DAO;
import com.configuracion.Configuracion_DTO;

public class Test_ConfiguracionDAO {
	// OBJETO A COMPROBAR
	private Configuracion_DAO confi_dao;
	private static int numero = 0;

	@BeforeClass
	public static void inicio_Prueba() {
		System.out.println("INICIAMOS LA PRUEBA ***********");
	}

	@AfterClass
	public static void fin_Prueba() {
		System.out.println("FINAL DE LA PRUEBA ***********");
	}

	@Before
	public void creacion_objeto() {
		// CREACION DEL OBJETO A TESTEAR
		confi_dao = new Configuracion_DAO();
		// DATOS DE LA PRUEBA
		confi_dao.setRuta_properties("/test/recursos/prueba_configuracion.properties");
		numero++;
		System.out.println("Numero de ejecuciones .. " + numero);
	}

	@After
	public void metodo_Final() {
		System.out.println("Final de prueba ..... ");
	}

	/**
	 * Prueba del constructor sinargumentos. La ruta del fichero se da llamando al
	 * accesor de la propiedad.
	 */
	@Test
	public void testConfiguracion_DAO() {
		System.out.println("LLAMADA AL METODO CONFIGURACION DAO");
		// OBTENCION DE PROPIEDADES PARA EL TESTEO INDIRECTO
		Properties lector_fichero = confi_dao.getDatos_configuracion();
		Configuracion_DTO dto_datos = confi_dao.getConfi_dto();
		// COMPROBACION DE LOS OBJETOS
		assertNotNull("ERROR EN LA CREACION DEL PROPERTIES", lector_fichero);
		assertNotNull("ERROR EN LA CREACION DEL DTO - CONFIGURACION_DTO", dto_datos);
	}

	/**
	 * Prueba del constructor con un argumento de tipo String para la ruta del
	 * fichero.
	 */
	@Test
	public void testConfiguracion_DAOString() {
		System.out.println("LLAMADA AL METODO CONFIGURACION DAO CON PARAMETRO");
		String ruta_constructor = "Prueba de creacion";
		confi_dao = new Configuracion_DAO(ruta_constructor);
		// OBTENCION DE PROPIEDADES PARA EL TESTEO INDIRECTO
		Properties lector_fichero = confi_dao.getDatos_configuracion();
		Configuracion_DTO dto_datos = confi_dao.getConfi_dto();
		String ruta_nombre = confi_dao.getRuta_properties();
		// COMPROBACION DE LOS OBJETOS
		assertNotNull("ERROR EN LA CREACION DEL PROPERTIES", lector_fichero);
		assertNotNull("ERROR EN LA CREACION DEL DTO - CONFIGURACION_DTO", dto_datos);
		// COMPROBACION DE LA RUTA DEL FICHERO
		assertNotNull("ERROR EN LA CREACION DE LA RUTA DEL PROPERTIES", ruta_nombre);
		assertEquals("EL VALOR DE LA PROPIEDAD NO ES CORRECTO", ruta_constructor, ruta_nombre);
	}

	/**
	 * Prueba de retorno de objeto.
	 */
	@Test
	public void testCargar_Configuracion() {
		System.out.println("LLAMADA AL METODO CARGAR CONFIGURACION");
		// LLAMADA AL METODO A COMPROBAR
		Configuracion_DTO datos_prueba = confi_dao.cargar_Configuracion();
		// COMPROBACION DE EL RETORNO DEL METODO
		assertNotNull("EL OBJETO RESULTANTE DE LA LECTURA DE LOS DATOS DE CONFIGURACION ES ERRONEO", datos_prueba);
	}

	/**
	 * Prueba del contenido del objeto
	 */
	@Test
	public void testCargar_ConfiguracionDos() {
		System.out.println("LLAMADA AL METODO CARGAR CONFIGURACION");
		// LLAMADA AL METODO A COMPROBAR
		Configuracion_DTO datos_prueba = confi_dao.cargar_Configuracion();
		// COMPROBACION DE LAS PROPIEDADES DEL OBJETO DEVUELTO POR EL METODO
		assertEquals("ERROR EN EL DATO VERSION", Float.valueOf((float) 1.8), datos_prueba.getVersion());
		assertEquals("ERROR EN EL DATO FECHA CREACION", "03/noviembre/2016",
				new SimpleDateFormat("dd/MMMM/yyyy").format(datos_prueba.getFecha_actualizacion()));
		assertEquals("ERROR EN EL DATO AUTOR", "Profesor - Juan Antonio Solves Garcia", datos_prueba.getAutor());
	}

	/**
	 * Prueba de comportamiento en caso de ruta erronea del fichero a tratar.
	 */
	@Test
	public void testCargar_ConfiguracionTRES() {
		// CARGA DE UNA RUTA ERRONEA PARA LA COMPROBACION DE LA GESTION DEL ERROR
		confi_dao.setRuta_properties("ruta erronea de carga");
		// LLAMADA AL METODO A COMPROBAR
		Configuracion_DTO datos_prueba = confi_dao.cargar_Configuracion();
		// COMPROBACION DE LA GESTION DE ERROR
		assertNull("ERROR EN LA GESTION DE LA RUTA ERRONEA", datos_prueba);
	}

	/**
	 * Prueba de modificacion del contenido del fichero de datos.
	 */
	@Test
	public void testModificar_Configuracion() {
		System.out.println("LLAMADA AL METODO MODIFICAR CONFIGURACION");
		// CREACION DEL DTO CON AL INFORMACION QUE MODIFICARA EL FICHERO
		Configuracion_DTO datos_prueba = new Configuracion_DTO();
		datos_prueba.setAutor("Profe");
		datos_prueba.setIdioma("es");
		datos_prueba.setModo_ejecucion("desarrollo");
		datos_prueba.setVersion(Float.valueOf("1.8"));
		datos_prueba.setFecha_actualizacion(new Date());
		// LLAMADA AL METODO PARA COMPROBAR SU FUNCIONAMIENTO
		boolean cambio = confi_dao.modificar_Configuracion(datos_prueba);
		// COMPROBACION DEL VALOR DE RETORNO
		assertTrue("ERROR EN EL VALOR DE RETORNO DE LA MODIFICACION", cambio);
		// LEEMOS EL CONTENIDO DEL FICHERO
		Configuracion_DTO datos_fichero = confi_dao.cargar_Configuracion();
		// COMPROBAMOS SI EL CAMBIO ESTA ECHO
		assertEquals("LA INFORMACION DE LA PROPIEDAD AUTOR NO ES CORRECTA", datos_prueba.getAutor(),
				datos_fichero.getAutor());
		assertEquals("LA INFORMACION DE LA PROPIEDAD IDIOMA NO ES CORRECTA", datos_prueba.getIdioma(),
				datos_fichero.getIdioma());
		assertEquals("LA INFORMACION DE LA PROPIEDAD MODO EJECUCION NO ES CORRECTA", datos_prueba.getModo_ejecucion(),
				datos_fichero.getModo_ejecucion());
	}

	@Test
	public void testEstablecer_OpcionesDefecto() {
		System.out.println("LLAMADA AL METODO ESTABLECER OPCIONES DEFECTO");
		fail("Not yet implemented");
	}

}
